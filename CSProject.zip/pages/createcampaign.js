import Form from '../components/Form/Form';

const createcampaign = () => {
  return (
    <div>
      <Form />
    </div>
  )
}

export default createcampaign