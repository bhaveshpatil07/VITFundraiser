  cout<<"Cipher text is: "<<cipherText<<endl<<endl;

    string decrypted = Decryption_Fuction(cipherText);

   cout<<"Decrypted text is: "<<decrypted<<endl<<endl;